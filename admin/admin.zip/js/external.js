// JavaScript Document

function IncludeJavaScript(jsFile)
{
	document.write('<script type="text/javascript" src="'+ jsFile + '"></script>');
}
IncludeJavaScript('js/jquery-1.11.2.min.js');
IncludeJavaScript('js/plugins/spinner/jquery.mousewheel.js');
IncludeJavaScript('js/jquery-ui.min.js');
IncludeJavaScript('js/plugins/forms/jquery.uniform.js');
IncludeJavaScript('js/plugins/forms/jquery.validationEngine-en.js');
IncludeJavaScript('js/plugins/forms/jquery.validationEngine.js');
IncludeJavaScript('js/plugins/forms/jquery.tagsinput.min.js');
IncludeJavaScript('js/plugins/forms/chosen.jquery.min.js');
IncludeJavaScript('js/plugins/wizard/jquery.form.js');
IncludeJavaScript('js/plugins/wizard/jquery.validate.min.js');
IncludeJavaScript('js/plugins/tables/datatable.js');
IncludeJavaScript('js/plugins/tables/tablesort.min.js');
IncludeJavaScript('js/plugins/ui/jquery.tipsy.js');
IncludeJavaScript('js/plugins/ui/jquery.collapsible.min.js');
IncludeJavaScript('js/plugins/ui/jquery.sourcerer.js');
IncludeJavaScript('js/plugins/ui/jquery.timeentry.min.js');
IncludeJavaScript('js/plugins/forms/jquery.dualListBox.js');
IncludeJavaScript('js/custom.js');
IncludeJavaScript('js/js_admin.js');
IncludeJavaScript('js/function.js');
IncludeJavaScript('js/ajax.js');
